import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Gem, LogOut, User, LayoutDashboard } from 'lucide-react'
import { useAuth } from '../hooks/useAuth'
import Button from './Button'

const Navbar = () => {
  const { isAuthenticated, user, logout } = useAuth()
  const navigate = useNavigate()

  const handleLogout = async () => {
    await logout()
    navigate('/login')
  }

  return (
    <nav className="navbar navbar-expand-lg luxury-navbar sticky-top">
      <div className="container">
        <Link className="navbar-brand d-flex align-items-center gap-2" to="/">
          <Gem size={28} className="text-gold" />
          <span className="brand-text">
            Alpha <span className="text-gold">Jewels</span>
          </span>
        </Link>

        <button
          className="navbar-toggler border-0"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#mainNavbar"
          aria-controls="mainNavbar"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon" />
        </button>

        <div className="collapse navbar-collapse" id="mainNavbar">
          <ul className="navbar-nav ms-auto align-items-lg-center gap-lg-2">
            <li className="nav-item">
              <NavLink className="nav-link" to="/" end>
                Home
              </NavLink>
            </li>

            {isAuthenticated ? (
              <>
                <li className="nav-item">
                  <NavLink className="nav-link d-flex align-items-center gap-1" to="/dashboard">
                    <LayoutDashboard size={16} />
                    Dashboard
                  </NavLink>
                </li>
                <li className="nav-item">
                  <NavLink className="nav-link d-flex align-items-center gap-1" to="/profile">
                    <User size={16} />
                    Profile
                  </NavLink>
                </li>
                <li className="nav-item ms-lg-2">
                  <Button
                    variant="outline-gold"
                    className="w-100"
                    icon={LogOut}
                    onClick={handleLogout}
                  >
                    Logout
                  </Button>
                </li>
                {user?.email && (
                  <li className="nav-item d-none d-xl-block">
                    <span className="nav-user-badge">{user.email}</span>
                  </li>
                )}
              </>
            ) : (
              <>
                <li className="nav-item">
                  <NavLink className="nav-link" to="/login">
                    Login
                  </NavLink>
                </li>
                <li className="nav-item ms-lg-2">
                  <NavLink to="/register">
                    <Button variant="gold" className="w-100">
                      Register
                    </Button>
                  </NavLink>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
