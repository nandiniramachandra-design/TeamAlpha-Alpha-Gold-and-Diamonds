import { createContext, useCallback, useEffect, useMemo, useState } from 'react'
import {
  loginUser,
  logoutUser,
  registerUser,
  forgotPassword,
  resetPassword,
  changePassword,
  extractErrorMessage,
} from '../services/authService'
import {
  getToken,
  setToken,
  getStoredUser,
  setStoredUser,
  clearAuthStorage,
  getRememberedEmail,
  setRememberedEmail,
} from '../utils/storage'
import { decodeJwtPayload } from '../utils/jwtUtils'

export const AuthContext = createContext(null)

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => getStoredUser())
  const [token, setTokenState] = useState(() => getToken())
  const [loading, setLoading] = useState(true)

  const isAuthenticated = Boolean(token)

  useEffect(() => {
    const storedToken = getToken()
    const payload = decodeJwtPayload(storedToken)

    if (storedToken && payload && !payload.isExpired) {
      setTokenState(storedToken)
      setUser((prev) => prev || { email: payload.email, role: payload.role })
    } else if (storedToken) {
      clearAuthStorage()
      setTokenState(null)
      setUser(null)
    }

    setLoading(false)
  }, [])

  const persistSession = useCallback((jwt, userData) => {
    setToken(jwt)
    setTokenState(jwt)
    setStoredUser(userData)
    setUser(userData)
  }, [])

  const login = useCallback(async (credentials, rememberEmail = false) => {
    const jwt = await loginUser(credentials)
    const payload = decodeJwtPayload(jwt)

    const userData = {
      email: payload?.email || credentials.email,
      role: payload?.role || 'USER',
    }

    persistSession(jwt, userData)

    if (rememberEmail) {
      setRememberedEmail(credentials.email)
    } else {
      setRememberedEmail('')
    }

    return userData
  }, [persistSession])

  const register = useCallback(async (payload) => {
    const registeredUser = await registerUser(payload)

    const userData = {
      id: registeredUser.id,
      fullName: registeredUser.fullName,
      email: registeredUser.email,
      phone: registeredUser.phone,
      role: registeredUser.role,
    }

    return userData
  }, [])

  const logout = useCallback(async () => {
    try {
      await logoutUser()
    } catch {
      // Clear local session even if backend logout fails
    } finally {
      clearAuthStorage()
      setTokenState(null)
      setUser(null)
    }
  }, [])

  const requestPasswordReset = useCallback(async (email) => {
    return forgotPassword({ email })
  }, [])

  const completePasswordReset = useCallback(async (payload) => {
    return resetPassword(payload)
  }, [])

  const updatePassword = useCallback(async (payload) => {
    return changePassword(payload)
  }, [])

  const updateProfile = useCallback((updates) => {
    setUser((prev) => {
      const next = { ...prev, ...updates }
      setStoredUser(next)
      return next
    })
  }, [])

  const value = useMemo(
    () => ({
      user,
      token,
      loading,
      isAuthenticated,
      rememberedEmail: getRememberedEmail(),
      login,
      register,
      logout,
      requestPasswordReset,
      completePasswordReset,
      updatePassword,
      updateProfile,
      getErrorMessage: extractErrorMessage,
    }),
    [
      user,
      token,
      loading,
      isAuthenticated,
      login,
      register,
      logout,
      requestPasswordReset,
      completePasswordReset,
      updatePassword,
      updateProfile,
    ]
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}
