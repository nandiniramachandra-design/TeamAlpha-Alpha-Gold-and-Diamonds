import { Link } from 'react-router-dom'
import { Sparkles, Shield, Truck, Award } from 'lucide-react'
import Button from '../components/Button'

const features = [
  { icon: Sparkles, title: 'Handcrafted Excellence', text: 'Every piece is meticulously crafted by master artisans.' },
  { icon: Shield, title: 'Certified Authenticity', text: 'BIS hallmarked gold and certified diamonds guaranteed.' },
  { icon: Truck, title: 'Insured Delivery', text: 'Secure, fully insured shipping to your doorstep.' },
  { icon: Award, title: 'Lifetime Service', text: 'Complimentary cleaning and maintenance for life.' },
]

const Home = () => {
  return (
    <div className="home-page">
      <section className="hero-section">
        <div className="hero-overlay" />
        <div className="container hero-content">
          <span className="hero-badge animate-fade-up">Premium Jewellery Collection</span>
          <h1 className="hero-title animate-fade-up delay-1">
            Discover Timeless <span className="text-gold">Elegance</span>
          </h1>
          <p className="hero-subtitle animate-fade-up delay-2">
            Explore our curated collection of gold, diamond, and platinum jewellery.
            Crafted for moments that last forever.
          </p>
          <div className="hero-actions animate-fade-up delay-3">
            <Link to="/register">
              <Button variant="gold" className="px-4">Create Account</Button>
            </Link>
            <Link to="/login">
              <Button variant="outline-gold" className="px-4">Sign In</Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="section-padding">
        <div className="container">
          <div className="text-center mb-5">
            <h2 className="section-title">Why Choose Alpha</h2>
            <p className="section-subtitle">Luxury you can trust, beauty you can wear</p>
          </div>

          <div className="row g-4">
            {features.map(({ icon: Icon, title, text }) => (
              <div className="col-md-6 col-lg-3" key={title}>
                <div className="feature-card h-100">
                  <div className="feature-icon">
                    <Icon size={28} />
                  </div>
                  <h5>{title}</h5>
                  <p>{text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="cta-section section-padding">
        <div className="container text-center">
          <h2 className="section-title mb-3">Begin Your Journey</h2>
          <p className="section-subtitle mb-4">
            Join Alpha Jewels today and unlock exclusive collections and member benefits.
          </p>
          <Link to="/register">
            <Button variant="gold" className="px-5">Get Started</Button>
          </Link>
        </div>
      </section>
    </div>
  )
}

export default Home
