import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Mail, KeyRound, Lock } from 'lucide-react'
import Input from '../components/Input'
import Button from '../components/Button'
import { useAuth } from '../hooks/useAuth'
import { useForm } from '../hooks/useForm'
import {
  validateEmail,
  validatePassword,
  validateConfirmPassword,
  validateRequired,
} from '../utils/validators'

const ResetPassword = () => {
  const navigate = useNavigate()
  const { completePasswordReset, getErrorMessage } = useAuth()
  const [submitting, setSubmitting] = useState(false)
  const [serverError, setServerError] = useState('')
  const [success, setSuccess] = useState('')

  const { values, errors, touched, handleChange, handleBlur, setAllErrors } = useForm({
    email: '',
    otp: '',
    newPassword: '',
    confirmPassword: '',
  })

  const validateForm = () => {
    const nextErrors = {
      email: validateEmail(values.email),
      otp: validateRequired(values.otp, 'OTP'),
      newPassword: validatePassword(values.newPassword),
      confirmPassword: validateConfirmPassword(values.newPassword, values.confirmPassword),
    }

    const filtered = Object.fromEntries(
      Object.entries(nextErrors).filter(([, msg]) => msg)
    )

    if (Object.keys(filtered).length > 0) {
      setAllErrors(filtered)
      return false
    }

    return true
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setServerError('')
    setSuccess('')

    if (!validateForm()) return

    setSubmitting(true)

    try {
      // Backend ResetPasswordRequest: email, otp, newPassword
      const message = await completePasswordReset({
        email: values.email.trim(),
        otp: values.otp.trim(),
        newPassword: values.newPassword,
      })

      setSuccess(message || 'Password reset successfully!')
      setTimeout(() => navigate('/login'), 2000)
    } catch (error) {
      setServerError(getErrorMessage(error))
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="auth-page">
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-lg-5 col-xl-4">
            <div className="auth-card animate-fade-up">
              <div className="auth-card-header text-center">
                <h1>Reset Password</h1>
                <p>Enter the OTP sent to your email and choose a new password</p>
              </div>

              {serverError && <div className="alert alert-danger">{serverError}</div>}
              {success && <div className="alert alert-success">{success}</div>}

              <form onSubmit={handleSubmit} noValidate>
                <Input
                  label="Email"
                  name="email"
                  type="email"
                  value={values.email}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  error={errors.email}
                  touched={touched.email}
                  placeholder="you@example.com"
                  required
                  icon={Mail}
                  autoComplete="email"
                />

                <Input
                  label="OTP / Token"
                  name="otp"
                  value={values.otp}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  error={errors.otp}
                  touched={touched.otp}
                  placeholder="6-digit OTP"
                  required
                  icon={KeyRound}
                  autoComplete="one-time-code"
                />

                <Input
                  label="New Password"
                  name="newPassword"
                  value={values.newPassword}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  error={errors.newPassword}
                  touched={touched.newPassword}
                  placeholder="Minimum 8 characters"
                  required
                  icon={Lock}
                  showPasswordToggle
                  autoComplete="new-password"
                />

                <Input
                  label="Confirm Password"
                  name="confirmPassword"
                  value={values.confirmPassword}
                  onChange={handleChange}
                  onBlur={handleBlur}
                  error={errors.confirmPassword}
                  touched={touched.confirmPassword}
                  placeholder="Re-enter new password"
                  required
                  showPasswordToggle
                  autoComplete="new-password"
                />

                <Button type="submit" variant="gold" className="w-100" loading={submitting}>
                  Reset Password
                </Button>
              </form>

              <p className="auth-footer-text text-center mt-4 mb-0">
                Need a new OTP? <Link to="/forgot-password">Request again</Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ResetPassword
